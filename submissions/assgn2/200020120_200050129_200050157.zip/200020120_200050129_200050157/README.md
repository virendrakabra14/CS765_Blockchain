# CS765
IIT Bombay (Spring 2023).

Running default config:
```sh
cd code
python3 main.py
```

Command line args can be viewed in main.py.