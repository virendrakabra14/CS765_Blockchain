#!/bin/bash

cd code
make
./sim > ../outfile