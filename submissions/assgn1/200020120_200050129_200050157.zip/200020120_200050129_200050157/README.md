# CS765
IIT Bombay (Spring 2023).

Running default config:
bash exec.sh

Otherwise run make from within code.
The executable will be generated as 'sim'.
Command line args can be viewed in main.cpp.