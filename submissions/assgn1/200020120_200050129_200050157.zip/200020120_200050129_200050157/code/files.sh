#!/bin/bash

mkdir outputs/$1
mv *.txt outputs/$1
cp run.sh outputs/$1