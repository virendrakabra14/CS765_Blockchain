# CS 765 Assignment 3

Steps to simulate:
1. In one terminal, run ganache
2. Run the deploy.sh script (./code/deploy.sh)
3. Copy the contract address to code/client.py (line 128)
4. Run the run.sh script (./code/run.sh)
