#!/bin/bash

# copy contract address to client.py
# deployed_contract_address=''paste-contract-address''
python3 client.py
